<!DOCTYPE HTML>
<php><head>
<title>KM - IDIOMAS</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="js/jquery.min.js"></script>
<!---strat-slider---->
<script type="text/javascript" src="js/modernizr.custom.28468.js"></script>

		 <!--- Hover Efeect --------------->
		 <script type="text/javascript" src="js/jquery.openCarousel.js"></script>
     	 <link href="css/image-hover.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.adipoli.min.js" type="text/javascript"></script>
          <script type="text/javascript">
            
            $(function(){
                 $('.row2').adipoli({
                    'startEffect' : 'overlay',
                    'hoverEffect' : 'sliceDown'
                });
                $('.row6').adipoli({
                    'startEffect' : 'grayscale',
                    'hoverEffect' : 'normal'
                });
            });
            
        </script>
        <link rel="stylesheet" type="text/css" href="css/raccordion.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/jquery.raccordion.js" type="text/javascript"></script>
    <script src="js/jquery.animation.easing.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(window).load(function () {
            $('#accordion-wrapper').raccordion({
                speed: 1000,
                sliderWidth: 940,
                sliderHeight: 400,
                autoCollapse: true
				
            });

        }); 
    </script>
    
    <script language="JavaScript">

<!--

function enviar() {

	if (checkdata()) {

		document.contacto.submit();

	}

}

function borrar() {

	document.contacto.reset();

}

function etrim(s)

{	var fin,str,re,u,ini, ini2

	str="";

	re = /\S/ig;

	ini = s.search("@");

	if (ini != -1){

		s = s.slice(ini + 1);

		u = s.slice(s.length-1, s.length);

		ini2 = s.search("@");

		if (ini2 != -1 ){

			alert("Debe ingresar una sola dirección de e-mail o la que ha ingresado es invalida");

			return(-1)

		}

	}

}

function jtrim(s)

{	var fin,str,re,u,ini

	str=""

	re = /\S/ig

	ini = s.search(re)

	if (ini != -1)	{

		s = s.slice(ini)

		u = s.slice(s.length-1, s.length)

		fin = u.search(re)

		while(fin == -1)

			{s = s.slice(0, s.length - 1)

			u = s.slice(s.length - 1, s.length)

			fin = u.search(re)}

		str = s

		}

	return(str)

}



function ValidarMail(sEmail)

{

var emailexp = /^[a-z_0-9\-\']+(\.[a-z_0-9\-\']+)*@[a-z_0-9\-]+(\.[a-z_0-9\-]+){1,}$/i



if (emailexp.test(sEmail) )

   return 0

else

   return 1

}

function checkdata()

{

     var uppervalue;


     if (document.contacto.Nombre.value.length == 0) {

         alert ("Debe ingresar su Nombre.");

         return false;

     }
	      if (document.contacto.mail.value.length == 0) {

         alert ("Debe ingresar su E-mail.");

         return false;

     }


	mail=jtrim(document.contacto.mail.value)



	arroba=etrim(mail)



	if (arroba == -1)

	{

		return false;

	}

	else

	{

		if (mail == "")

		{

		  alert("Debe ingresar su e-mail.")

			document.contacto.mail.focus();

			return false;

		}

		else

		{

			if (ValidarMail(mail))

			{

				alert("La dirección de e-mail no es válida. Verifique no estar dejando espacios en blanco.")

				document.contacto.mail.focus();

				return false;

			}

		}

	}

    return true;

}

//-->

</script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
        			  
        <!--- End Hover Efeect --------------->
        
        <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-59930569-1', 'auto');
  ga('send', 'pageview');

</script>

</head>
<body>
<div class="header">
 	<div class="container">
	  <div class="header-top">
	        <div class="logo">
				<a href="index.php"><img src="images/Logo.jpg" alt=""/></a>
			 </div>
		     <div class="h_menu4"><!-- start h_menu4 -->
				
				<ul class="nav">
					<li ><a href="index.php">Home</a></li>
					<li><a href="Servicios.php">Servicios</a></li>
					<li><a href="Nuestros_Clientes.php">Nuestros Clientes</a></li>
					<li class="active"><a href="Contacto.php" class="btn-success">Contacto</a></li>
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu4 -->
			<div class="clearfix"> </div>
		  </div><!-- end header_main4 -->
          
          <div class="h_menu2"><!-- start h_menu2 -->
				
				<ul class="nav2">
					<li><a href="Quienes_Somos.php">Quiénes Somos</a></li>
					<li><a href="Empresas.php">Empresas</a></li>
					<li><a href="Iniciativa_Individual.php">Iniciativa Individual</a></li>
					<li><a href="Chino.php">Chino</a></li>
                    <li><a href="Ingles_Portugues.php">Inglés - Portugués</a></li>
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu2 -->
	</div>
</div>
<div class="main">
	<div class="container">
   
   <img src="images/banner_contacto.jpg" width="940" height="190" class="imgbanner"></div>

</div>


	  <!---//End-da-features----->	
	  
      <div class="about">
		<div class="container">
			<section class="title-section">
			<h1 class="title-header">
			CONTACTO </h1>
		  </section>
          				   <p class="f_text">Complete el siguiente formulario para contactarse con nosotros.</p>
			<div class="row contact_top">
            
		       <div class="col-md-8 contact_left">

				  <form name="contacto" id="contacto" method="post" action="enviarporcorreo.php">
      
      <div class="form_details" id="form_details">
        
          <input name="Nombre" type="text" class="text" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Nombre';}" value="Nombre" />
     
            
          <input name="Telefono" type="text" class="text"  value="Teléfono"onfocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Teléfono';}"/>
         
          <input name="mail" type="text" class="text" value="Email"onfocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Email';}"/>
          <textarea name="Comentarios" class="text" id="Comentarios" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Comentarios';}">Comentarios</textarea>
          
          <a href= "javascript:enviar()"

		  		onMouseOver="document.enviar.src='images/btn_enviar_.png';"

		  		onMouseOut="document.enviar.src='images/btn_enviar.png';"><img src="images/btn_enviar.png" name="enviar" ></a>
                
         <a href= "javascript:borrar()"

				onMouseOver="document.borrar.src='images/btn_borrar_.png';"

				onMouseOut="document.borrar.src='images/btn_borrar.png';"><img src="images/btn_borrar.png" name="borrar"></a>
              </div >
      </form>
	          </div>
		        
      					<div class="company_ad">
				     		<p><a href="mailto:info@km-idiomas.com.ar" target="_new" class="Mail"> info@km-idiomas.com.ar</a></p>
                   </div>
					  <p class="f_text">Prof. Karina Coco: 11 40 28 12 54<br>
                      <p class="f_text">Lic. Mónica Villar: 11 41 79 82 24</p>

						 	 	
				   			</address>
   		  </div>


 <br> <br> <br>
          <section class="title-section">
			<h1 class="title-header">
			ADJUNTA TU CURRÍCULUM </h1>
             <p class="f_text">Si estás interesado/a en formar parte de nuestro equipo de trabajo, podés adjuntar tu CV</p>
  </section>
   <form action="enviar.php" method="post" enctype="multipart/form-data" class="form_details" id="formulario">
                  <input type="hidden" name="recipient" value="info@km-idiomas.com.ar">
      <input type="hidden" name="subject" value="Curriculum Vitae">
        <input type="hidden" name="redirect" value="http://www.km-idiomas.com.ar/index.htm">
		                        
                                      <input name="archivo1" type="file" id="archivo1">
                                    
                                      <input type="submit" name="Submit" value="enviar">
                                    
                              </form>

	    </div>				
				</div>	
			 </div>				
		  </div>	
	    </div>

</div >
<!----/start-footer---->
	    <div class="footer">
			<div class="container">
				
				<div class="footer-grid">
					
				    <ul class="list1">
					<li><a href="index.php">Home</a></li>
					<li><a href="Servicios.php">Servicios</a></li>
					<li><a href="Nuestros_Clientes.php">Nuestros Clientes</a></li>
					<li><a href="Contacto.php">Contacto</a></li>
				    </ul>
				</div>
				<div class="footer-grid">
					
					<ul class="list1">
					<li><a href="Quienes_Somos.php">Quiénes Somos</a></li>
					<li><a href="Empresas.php">Empresas</a></li>
					<li><a href="Iniciativa_Individual.php">Iniciativa Individual</a></li>
					<li><a href="Chino.php">Chino</a></li>
                    <li><a href="Ingles_Portugues.php">Inglés - Portugués</a></li>
					</ul>
				  </div>
				  <div class="footer-grid">
					  <h3>Contacto</h3><br>
					  <p>11 40 28 12 54<br>
                      <p>11 41 79 82 24</p>
				      
				 </div>
				 <div class="footer-grid footer-grid_last">
					
					 <div class="copy"> 
				   <p><a href="mailto:info@km-idiomas.com.ar" target="_new"> info@km-idiomas.com.ar</a></p>
                   </div>
			     </div>
				 <div class="clearfix"> </div>
				<div class="footer-bottom">
	     	  	<div class="copy">
				   <p>&copy; 2014  - KM IDIOMAS  <br><a href="http://www.km-idiomas.com.ar" target="_blank"> www.km-idiomas.com.ar</a></p>
			    </div>
			    <div class="footer-logo">
                <div class="copy">
                <p></p>
			       </div> 
			    </div>
			    <div class="clearfix"> </div>
			  </div>
			</div>
		</div>	
</body>
</php>		