<!DOCTYPE HTML>
<php><head>
<title>KM - IDIOMAS</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="js/jquery.min.js"></script>
<!---strat-slider---->
<script type="text/javascript" src="js/modernizr.custom.28468.js"></script>

		 <!--- Hover Efeect --------------->
		 <script type="text/javascript" src="js/jquery.openCarousel.js"></script>
     	 <link href="css/image-hover.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.adipoli.min.js" type="text/javascript"></script>
          <script type="text/javascript">
            
            $(function(){
                 $('.row2').adipoli({
                    'startEffect' : 'overlay',
                    'hoverEffect' : 'sliceDown'
                });
                $('.row6').adipoli({
                    'startEffect' : 'grayscale',
                    'hoverEffect' : 'normal'
                });
            });
            
        </script>
        <link rel="stylesheet" type="text/css" href="css/raccordion.css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/jquery.raccordion.js" type="text/javascript"></script>
    <script src="js/jquery.animation.easing.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(window).load(function () {
            $('#accordion-wrapper').raccordion({
                speed: 1000,
                sliderWidth: 940,
                sliderHeight: 400,
                autoCollapse: false
				
            });

        }); 
    </script>
        			  
        <!--- End Hover Efeect --------------->
        <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-59930569-1', 'auto');
  ga('send', 'pageview');

</script>

</head>
<body>
<div class="header">
 	<div class="container">
	  <div class="header-top">
	        <div class="logo">
				<a href="index.php"><img src="images/Logo.jpg" alt=""/></a>
			 </div>
		     <div class="h_menu4"><!-- start h_menu4 -->
				
				<ul class="nav">
					<li><a href="index.php">Home</a></li>
					<li><a href="Servicios.php">Servicios</a></li>
					<li><a href="Nuestros_Clientes.php">Nuestros Clientes</a></li>
					<li><a href="Contacto.php">Contacto</a></li>
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu4 -->
			<div class="clearfix"> </div>
		  </div><!-- end header_main4 -->
          
          <div class="h_menu2"><!-- start h_menu2 -->
				
				<ul class="nav2">
					<li><a href="Quienes_Somos.php">Quiénes Somos</a></li>
					<li><a href="Empresas.php">Empresas</a></li>
					<li><a href="Iniciativa_Individual.php">Iniciativa Individual</a></li>
					<li><a href="Chino.php">Chino</a></li>
                    <li><a href="Ingles_Portugues.php">Inglés - Portugués</a></li>
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu2 -->
	</div>
</div>
<div class="main">
	<div class="container">
   <div id="accordion-wrapper">
            <div class="slide">
                <img src="images/slide3_.jpg" border="0" usemap="#Map" />
                <map name="Map">
                  <area shape="rect" coords="443,340,545,373" href="Iniciativa_Individual.php">
                </map>
</div>
            <div class="slide">
                <img src="images/slide1.jpg" border="0" usemap="#Map2" />
                <map name="Map2">
                  <area shape="rect" coords="443,339,545,373" href="Quienes_Somos.php">
                </map>
      </div>
            <div class="slide">
                <img src="images/slide2.jpg" border="0" usemap="#Map3" />
                <map name="Map3">
                  <area shape="rect" coords="442,340,545,373" href="Empresas.php">
                </map>
      </div>
            <div class="slide">
                <img src="images/slide4.jpg" border="0" usemap="#Map4" />
                <map name="Map4">
                  <area shape="rect" coords="441,340,545,373" href="Chino.php">
                </map>
      </div>
            <div class="slide">
                <img src="images/slide5.jpg" border="0" usemap="#Map5" />
                <map name="Map5">
                  <area shape="rect" coords="442,340,545,374" href="Ingles_Portugues.php">
                </map>
          </div>
            
        </div>
   </div>

 </div>
	
	  <!---//End-da-features----->	
	  

	  	<div class="about">
	<div class="container">
		<div class="about-top">
	  	  <section class="title-section">
			<h1 class="title-header">
			INICIATIVA INDIVIDUAL </h1> 
		  </section>
	  		<div class="about-desc">   
			   <p>En una primer entrevista conversaríamos acerca de: tus necesidades, intereses, posibilidades y disponibilidad horaria.<br><br>

Entendemos que todos podemos aprender, por lo que nos esforzamos para que cada persona encuentre un espacio en donde pueda descubrir y desarrollar sus propias estrategias de aprendizaje, en un ambiente de distensión y comodidad.
<br><br>
<b>Tu éxito en la comunicación en el idioma extranjero es también el nuestro.</b>
</p>			    

		   </div>
	    </div>	
      </div>
     </div>
			
<!----/start-footer---->
	    <div class="footer">
			<div class="container">
				
				<div class="footer-grid">
					
				    <ul class="list1">
					<li><a href="index.php">Home</a></li>
					<li><a href="Servicios.php">Servicios</a></li>
					<li><a href="Nuestros_Clientes.php">Nuestros Clientes</a></li>
					<li><a href="Contacto.php">Contacto</a></li>
				    </ul>
				</div>
				<div class="footer-grid">
					
					<ul class="list1">
					<li><a href="Quienes_Somos.php">Quiénes Somos</a></li>
					<li><a href="Empresas.php">Empresas</a></li>
					<li><a href="Iniciativa_Individual.php">Iniciativa Individual</a></li>
					<li><a href="Chino.php">Chino</a></li>
                    <li><a href="Ingles_Portugues.php">Inglés - Portugués</a></li>
					</ul>
				  </div>
				  <div class="footer-grid">
					  <h3>Contacto</h3><br>
					  <p>11 40 28 12 54<br>
                      <p>11 41 79 82 24</p>
				      
				 </div>
				 <div class="footer-grid footer-grid_last">
					
					 <div class="copy"> 
				   <p><a href="mailto:info@km-idiomas.com.ar" target="_new"> info@km-idiomas.com.ar</a></p>
                   </div>
			     </div>
				 <div class="clearfix"> </div>
				<div class="footer-bottom">
	     	  	<div class="copy">
				   <p>&copy; 2014  - KM IDIOMAS  <br><a href="http://www.km-idiomas.com.ar" target="_blank"> www.km-idiomas.com.ar</a></p>
			    </div>
			    <div class="footer-logo">
                <div class="copy">
                <p></p>
			       </div> 
			    </div>
			    <div class="clearfix"> </div>
			  </div>
			</div>
		</div>	
</body>
</php>		