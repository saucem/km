<!DOCTYPE HTML>
<php><head>
<title>KM - IDIOMAS</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<script src="js/modernizr.custom.js"></script>
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
    
    
    
</head>
<body>
<div class="header">
 	<div class="container">
	  <div class="header-top">
	        <div class="logo">
				<a href="index.php"><img src="images/Logo.jpg" alt="" align="absmiddle"/></a>
   </div>
		     <div id="dl-menu" class="dl-menuwrapper">
						<button class="dl-trigger">Open Menu</button>
						<ul class="dl-menu">
							<li>
								<a href="index.php">HOME</a>
							</li>
                            <li>
								<a href="Quienes_Somos.php">QUIÉNES SOMOS</a>
							</li>	
							<li>
								<a href="Servicios.php">SERVICIOS</a>
							</li>	
							<li>
								<a href="Iniciativa_Individual.php">INICIATIVA INDIVIDUAL</a>
							</li>
							<li>
								<a href="Chino.php">CHINO</a>
							</li>
                            <li>
								<a href="Ingles_Portugues.php">INGLÉS-PORTUGUÉS</a>
							</li>
                            <li>
								<a href="Nuestros_Clientes.php">NUESTROS CLIENTES</a>
							</li>
                            <li>
								<a href="Empresas.php">EMPRESAS</a>
							</li>
							<li>
								<a href="Contacto.php">CONTACTO</a>
							</li>
						</ul>
					</div><!-- /dl-menuwrapper -->

			</div>	
	</div>
</div>

					  <div class="event-grid">
                      
					  	<div class="event_img"> 
                        <img src="images/slide2_m.jpg" width="100%">
					    </div>
                        
</div>
	
	  <!---//End-da-features----->	
	  

	  	<div class="about">
	<div class="container">
		<div class="about-top">
	  	  <section class="title-section">
			<h1 class="title-header">
			EMPRESAS </h1> 
		  </section>
	  		<div class="about-desc">   

			         <p>Una capacitación diseñada a partir del análisis de tus necesidades, modalidad de trabajo e intereses, para optimizar tiempo y desarrollar habilidades.  Valoramos tu inversión de tiempo y recursos para potenciar el rendimiento de tu equipo de trabajo.<br><br>
			           
			           <b>NUESTRA METODOLOGÍA</b></p><br>
<div class="about-desc3">
			           <p>Entrevista inicial donde conocemos tus necesidades, modalidad de trabajo, intereses y 
			           conocimientos previos del idioma.<br><br>
			           Acuerdo del diseño e implementación del curso, teniendo en cuenta nuestros cuatro aspectos básicos: cantidad, calidad, continuidad y compromiso.<br><br>
			           Seguimiento del trabajo individual, ajustes sobre la marcha, evaluación de progreso y de 
			           logros de objetivos.
		             </p>
</div>
          </div>
	    </div>	
      </div>
     </div>
			
<!----/start-footer---->
	    <div class="footer">
			<div class="container">
				
				
				
	    <div class="footer-grid">
					  <h3>Contacto</h3><br>
					  <p>11 40 28 12 54<br>
                      <p>11 41 79 82 24</p>
				 </div>
				 <div class="footer-grid footer-grid_last">
					
					 <div class="copy"> 
				   <p><a href="mailto:info@km-idiomas.com.ar" target="_new"> info@km-idiomas.com.ar</a></p>
                   </div>
			     </div>
				 <div class="clearfix"> </div>
				<div class="footer-bottom">
	     	  	<div class="copy">
				   <p>&copy; 2014  - KM IDIOMAS  <a href="http://www.km-idiomas.com.ar" target="_blank"><br> www.km-idiomas.com.ar</a></p>
			    </div>
			    <div class="footer-logo">
                <div class="copy">
                <p><a href="http://www.visual.com.ar" target="_blank">VISUAL</a></p>
			       </div> 
			    </div>
			    <div class="clearfix"> </div>
			  </div>
			</div>
		</div>	
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="js/jquery.dlmenu.js"></script>
		<script>
			$(function() {
				$( '#dl-menu' ).dlmenu({
					animationClasses : { classin : 'dl-animate-in-2', classout : 'dl-animate-out-2' }
				});
			});
		</script>
</body>
</php>		