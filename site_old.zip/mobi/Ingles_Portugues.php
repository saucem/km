<!DOCTYPE HTML>
<php><head>
<title>KM - IDIOMAS</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<script src="js/modernizr.custom.js"></script>
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
    
    
    
</head>
<body>
<div class="header">
 	<div class="container">
	  <div class="header-top">
	        <div class="logo">
				<a href="index.php"><img src="images/Logo.jpg" alt="" align="absmiddle"/></a>
   </div>
		     <div id="dl-menu" class="dl-menuwrapper">
						<button class="dl-trigger">Open Menu</button>
						<ul class="dl-menu">
							<li>
								<a href="index.php">HOME</a>
							</li>
                            <li>
								<a href="Quienes_Somos.php">QUIÉNES SOMOS</a>
							</li>	
							<li>
								<a href="Servicios.php">SERVICIOS</a>
							</li>	
							<li>
								<a href="Iniciativa_Individual.php">INICIATIVA INDIVIDUAL</a>
							</li>
							<li>
								<a href="Chino.php">CHINO</a>
							</li>
                            <li>
								<a href="Ingles_Portugues.php">INGLÉS-PORTUGUÉS</a>
							</li>
                            <li>
								<a href="Nuestros_Clientes.php">NUESTROS CLIENTES</a>
							</li>
                            <li>
								<a href="Empresas.php">EMPRESAS</a>
							</li>
							<li>
								<a href="Contacto.php">CONTACTO</a>
							</li>
						</ul>
					</div><!-- /dl-menuwrapper -->

			</div>	
	</div>
</div>

					  <div class="event-grid">
                      
					  	<div class="event_img"> 
                        <img src="images/slide5_m.jpg" width="100%" height="100%">
					    </div>
                        
</div>
	
	  <!---//End-da-features----->	
	  

	  	<div class="about">
	<div class="container">
		<div class="about-top">
	  	  <section class="title-section">
			<h1 class="title-header">
			INGLÉS - PORTUGUÉS </h1> 
		  </section>
	  		<div class="about-desc">   
			
			         <p><B>CURSOS REGULARES E INTENSIVOS<br><br>
              TALLERES SOBRE: </B></p><br>
<div class="about-desc3">
			          <p> <img src="images/marker.png" width="30" height="15">Telephoning (Comunicación telefónica)<br><br>
			           <img src="images/marker.png" width="30" height="15">Negotiating (Estrategias lingüísticas en una negociación)<br><br>
			           <img src="images/marker.png" width="30" height="15">Business Writing (Redacción de distintos tipos de textos, con fines comerciales)<br><br>
			           <img src="images/marker.png" width="30" height="15">Socializing (Interactuar a través de una conversación amena, cordial y amable)<br><br>
			           <img src="images/marker.png" width="30" height="15">Interviewing (El lenguaje de las entrevistas, qué decir y cómo hacerlo)<br><br>
			          <img src="images/marker.png" width="30" height="15">Making Presentations (Diseño, armado y exposición de presentaciones)<br><br>
			           <img src="images/marker.png" width="30" height="15">Meetings (Aspectos formales de una reunión, estrategias lingüísticas)<br><br>
		             </p>

 </div><br>
                      			         <p><B>TRADUCCIONES AL ESPAÑOL Y DEL ESPAÑOL A UN IDIOMA EXTRANJERO<br></B></p><br>
                                         <p><B>INTERPRETACIONES CONSECUTIVAS Y SIMULTÁNEAS<br><br></B></p><br>
           </div>
	    </div>	
      </div>
     </div>
			
<!----/start-footer---->
	    <div class="footer">
			<div class="container">
				
				
				
	    <div class="footer-grid">
					  <h3>Contacto</h3><br>
					  <p>11 40 28 12 54<br>
                      <p>11 41 79 82 24</p>
				 </div>
				 <div class="footer-grid footer-grid_last">
					
					 <div class="copy"> 
				   <p><a href="mailto:info@km-idiomas.com.ar" target="_new"> info@km-idiomas.com.ar</a></p>
                   </div>
			     </div>
				 <div class="clearfix"> </div>
				<div class="footer-bottom">
	     	  	<div class="copy">
				   <p>&copy; 2014  - KM IDIOMAS  <a href="http://www.km-idiomas.com.ar" target="_blank"><br> www.km-idiomas.com.ar</a></p>
			    </div>
			    <div class="footer-logo">
                <div class="copy">
                <p><a href="http://www.visual.com.ar" target="_blank"> VISUAL</a></p>
			       </div> 
			    </div>
			    <div class="clearfix"> </div>
			  </div>
			</div>
		</div>	
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="js/jquery.dlmenu.js"></script>
		<script>
			$(function() {
				$( '#dl-menu' ).dlmenu({
					animationClasses : { classin : 'dl-animate-in-2', classout : 'dl-animate-out-2' }
				});
			});
		</script>
</body>
</php>		