<?php
	$msg = "Mensaje enviado desde el Formulario de Contacto Web \n\n";
	$msg = $msg."---------------------- \n\n";

	$field_name = array_keys($HTTP_POST_VARS);	// guardamos todos los nombres de los
												// "fields" existentes en el form.
	$value_name = array_values($HTTP_POST_VARS);// guardamos todos los valores en
												// sus respectivas variables.

	for ($i=0;$i<count($field_name);$i++)
	{
		if ($field_name[$i]!="Submit")
		{
			$msg .= "".$field_name[$i].": ".$value_name[$i]."\n\n";
		}
	}

	$recipient 	= "info@km-idiomas.com.ar";							// el mail deseado
	$subject 	= "Mensaje desde www.km-idiomas.com.ar";	// el titulo del mail

	$header = "From:".$_POST["mail"]."\nReply-To:".$_POST["mail"]."\n";
	$header .= "X-Mailer:PHP/".phpversion()."\n";
	$header .= "Mime-Version: 1.0\n";
	$header .= "Content-Type: text/plain";

	mail($recipient, $subject, $msg, $header);							// mandamos el mail con los todos los datos
	header('location:Gracias.html');											// y vamos a la pagina en donde nos dan
?>